/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.evenandoddnumbers;
import java.util.Scanner;

/**
 *
 * @author Lenovo-User
 */
public class EvenAndOddNumbers {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        // Prompt the user to enter a number.
        System.out.println("Enter a number: ");
    int number = sc.nextInt();
        if (number % 2 == 0) {
            System.out.println(number + " is an even number.");
        } else {
            System.out.println(number + " is an odd number.");
        }
        sc.close();
    }
}


